# Repository for mailu helm charts

[Chart documentation](mailu/README.md)

[![Build Status](https://travis-ci.org/Mailu/helm-charts.svg?branch=master)](https://travis-ci.org/Mailu/helm-charts)
